﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace WcfService1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public string GetData(string payload)
        {
            string value = string.Empty;
            string verboseMsg = "";
            try
            {

                string xsdfile = @"~/xmlSample/ValidateXML.xsd";

                var schema = new XmlSchemaSet();
                schema.Add("", xsdfile);
                var Message = "";

                XDocument document = XDocument.Load(payload);
                document.Validate(schema, (o, e) =>
                {
                    verboseMsg += e.Message + Environment.NewLine;
                });
                if (verboseMsg == "")
                {
                    value = "the document was structured correctly";
                }
                else
                {
                    
                    XmlDocument xDoc = new XmlDocument();
                    using (StreamReader sr = new StreamReader(payload))
                    {
                        xDoc.Load(sr);      //load up the xml from the location 
                    }
                    XmlNode Node = xDoc.SelectSingleNode("//InputDocument/DeclarationList/Declaration[@Command='DEFAULT']");
                    if (Node != null)
                    {
                        value = "-1";
                    }

                    XmlNode Node2 = xDoc.SelectSingleNode("//InputDocument/DeclarationList/Declaration/DeclarationHeader");
                    foreach (XmlNode n in Node2.ChildNodes)
                    {
                        if (n.Name.Contains("SiteID"))
                        {
                            string txt = n.InnerText;
                            if (txt == "DUB")
                            {
                                value = @"invalid Site specified";
                            }
                        }
                    }

                }

            }
            catch (Exception ex)
            {

            }
            return value;
        }

        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
