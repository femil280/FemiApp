﻿using FemiTestApp.Services;
using System;

namespace FemiTestApp
{
    class Program
    {
        static void Main(string[] args)
        {
            IService TestService = new Repository.ServiceRepository();
            string textpath = "path to text file";
            string xmlpath = "path to xml file";
            //var TestRead = TestService.ReadAllText(textpath);

            TestService.MappXmlDoc(textpath);


        }
    }
}
