﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FemiTestApp.Services
{
    public interface IService
    {
        List<string> ReadAllText(string textFile);

        void MappXmlDoc(string xml);

    }
}
