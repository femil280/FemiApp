﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FemiTestApp.Utilities
{
    public class ObjectClass
    {
        public string RefText { get; set; }
    }
}
