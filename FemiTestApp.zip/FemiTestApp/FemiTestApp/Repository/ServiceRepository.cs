﻿using FemiTestApp.Services;
using FemiTestApp.Utilities;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;

namespace FemiTestApp.Repository
{
    public class ServiceRepository : IService
    {
        public void MappXmlDoc(string sXmlFilePath)
        {
            List<string> ilist = new List<string> { "MWB", "TRV", "CAR" };
            foreach(var item in ilist)
            {
                try
                {
                    XmlDocument xDoc = new XmlDocument();
                    using (StreamReader sr = new StreamReader(sXmlFilePath))
                    {
                        xDoc.Load(sr);
                    }
                    XmlNode Node = xDoc.SelectSingleNode("//InputDocument/DeclarationList/Declaration/DeclarationHeader/Reference[@RefCode='"+item+"']");
                    if (Node != null)
                    {
                        ObjectClass obj = new ObjectClass();
                        
                        switch (item)
                        {
                            case "MWB":
                                foreach (XmlNode cn1 in Node.ChildNodes)
                                {
                                    if (cn1.Name.Contains("RefText"))
                                    {
                                        obj.RefText = cn1.InnerText;
                                    }
                                }
                                break;
                            case "TRV":
                                foreach (XmlNode cn1 in Node.ChildNodes)
                                {
                                    if (cn1.Name.Contains("RefText"))
                                    {
                                        obj.RefText = cn1.InnerText;
                                    }
                                }
                                break;
                            case "CAR":
                                foreach (XmlNode cn1 in Node.ChildNodes)
                                {
                                    if (cn1.Name.Contains("RefText"))
                                    {
                                        obj.RefText = cn1.InnerText;
                                    }
                                }
                                break;
                        }

                    }
                }
                catch (Exception ex)
                {
                    ex.ToString();
                }
            }
            
        }

        public List<string> ReadAllText(string textFile)
        {
            List<string> ans = new List<string>();
            string line = string.Empty;
            string newTextFile = @"C:\Users\WriteLines.txt";
            StreamWriter writer = new StreamWriter(newTextFile);
            StreamReader reader = new StreamReader(textFile);
            try
            {
                while ((line = reader.ReadLine()) != null)
                {
                    if(!line.Contains("LOC"))
                    {
                        writer.WriteLine(line);
                    }
                }
                writer.Close();
            }
            catch(Exception ex)
            {

            }
            ans = CreateArray(newTextFile);
            return ans;
        }
        public List<string> CreateArray(string file)
        {
            List<string> arr = new List<string>();
            string li = string.Empty;
            string sub = string.Empty;
            using (StreamReader reader = new StreamReader("file"))
            {
                while((li = reader.ReadLine()) != null)
                {
                    string[] section = li.Split('+');
                    for(int i=0; i <= section.Length; i ++)
                    {
                        string SecThirdVal = section[1] + section[2];
                        arr.Add(SecThirdVal);
                        break;
                    }
                }
            }
            return arr;
        }


    }
}
